BSERC GENAI INTERNSHIP — WEEK 1 PROJECT 2
THINKING IN HTML | AI AND MACHINE LEARNING FUNDAMENTALS

CONTENTS
1. 01_AI_ML_Revision_Dashboard.html
   Official option: Revision or teaching dashboard.
   Includes topic completion tracking, search, category filter, expandable notes, examples, flashcards, quick scored quiz, 25-minute countdown and local progress storage.

2. 02_Interactive_2D_Neural_Model.html
   Official option: Interactive 2D / 3D model.
   A canvas-based 2D neural-network model. Change two inputs, connection strength and viewing angle; show/hide labels; run/pause the animated signal; load example values; reset the model. The output is calculated with sigmoid activations.

3. 03_ML_Decision_Helper.html
   Official option: Decision helper.
   Compares five algorithms (Decision Tree, Logistic Regression, Random Forest, Linear Regression and K-means). Change task type, dataset size, label availability, pattern complexity and priorities to re-rank suitable methods live. Includes three preset scenarios and expandable algorithm explanations.

HOW TO OPEN
1. Download and extract the ZIP.
2. Open any .html file by double-clicking it.
3. Use the navigation links at the top to move between pages.
No installation, server, database, login, API key or internet connection is required.

BROWSER SUPPORT
Designed for recent desktop and mobile versions of Chrome, Edge, Firefox and Safari. The revision dashboard saves completed topics in localStorage on the current browser/device.

IMPORTANT LIMITATIONS
- The neural network is a simplified educational forward-pass illustration, not a trained model.
- The decision helper uses transparent heuristic fit scores, not measured benchmark performance. Validate real models with appropriate datasets, metrics and cross-validation.
- The dashboard's progress is stored locally in the browser and does not sync between devices.

TESTING
The final package includes static HTML/JavaScript checks, internal navigation checks, external dependency checks and ZIP integrity/size checks. Full interactive browser testing and physical-device testing should be completed by opening the pages on your own laptop and phone. Do not treat static syntax checks as proof of full visual or browser QA.
